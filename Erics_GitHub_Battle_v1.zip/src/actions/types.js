export const SET_PLAYER_ONE ="Set-Player-One";
export const SET_PLAYER_TWO = "Set-Player-Two";

export const RESET_PLAYERS = "Reset-Players";

export const UPATE_RANKINGS = "Update-Rankings";
